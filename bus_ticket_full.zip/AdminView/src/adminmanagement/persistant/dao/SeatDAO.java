package adminmanagement.persistant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.stereotype.Service;

import adminmanagement.persistant.dto.BusRequestDTO;
import adminmanagement.persistant.dto.SeatRequestDTO;

@Service("seatDao")

public class SeatDAO {
	public static Connection con=null;
	static {
		con=MyConnection.getConnection();
	}

	public int insertData(SeatRequestDTO dto) {
		int result=0;
		String sql="insert into seat(seat_1,seat_2,seat_3,seat_4,seat_5,seat_6,seat_7,seat_8,seat_9,seat_10) values(?,?,?,?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, dto.getSeat1());
			ps.setInt(2, dto.getSeat2());
			ps.setInt(3, dto.getSeat3());
			ps.setInt(4, dto.getSeat4());
			ps.setInt(5, dto.getSeat5());
			ps.setInt(6, dto.getSeat6());
			ps.setInt(7, dto.getSeat7());
			ps.setInt(8, dto.getSeat8());
			ps.setInt(9, dto.getSeat9());
			ps.setInt(10, dto.getSeat10());
			
		} catch (SQLException e) {
			System.out.println("Database error"+e.getMessage());
		}
		return result;
	}
}
