package adminmanagement.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import adminmanagement.model.ScheduleBean;
import adminmanagement.persistant.dao.ScheduleDAO;
import adminmanagement.persistant.dto.ScheduleRequestDTO;
import adminmanagement.persistant.dto.ScheduleResponseDTO;



@Controller
public class ScheduleController {
	@Autowired
	private ScheduleDAO dao;
	
	@RequestMapping(value="/displaySchedule",method=RequestMethod.GET)
	public String displayView(ModelMap model) {
		ArrayList<ScheduleResponseDTO> list=dao.selectAll();
		model.addAttribute("list",list);
		return "displaySchedule";
	}
	
	@RequestMapping(value="/setupaddSchedule/{busId}",method=RequestMethod.GET)
	public ModelAndView setupaddSchedule(ScheduleBean bean,ModelMap model) {
		ArrayList<ScheduleResponseDTO> list=dao.selectAll();
		if (list.size()==0) {
			
			bean.setDateId("SCH001");
		}else {
			int tempId = Integer.parseInt (list.get (list.size()-1).getDateId().substring(3))+1;
					String dateId=String.format("SCH%03d",tempId); 
					bean.setDateId(dateId) ;
		}return new ModelAndView("addSchedule","bean",bean);
	}
	
	@RequestMapping(value="/addSchedule",method=RequestMethod.POST)
	public String addSchedule(@ModelAttribute("bean")@Validated ScheduleBean bean,
			BindingResult bs, ModelMap model) {
		if(bs.hasErrors()) {
			return "addSchedule";
		}
		ScheduleRequestDTO dto=new ScheduleRequestDTO();
		dto.setDateId(bean.getDateId());
		dto.setDate(bean.getDate());
		dto.setTime(bean.getTime());
		dto.setBusId(bean.getBusId());
		dto.setBusType(bean.getBusType());
		dto.setSource(bean.getSource());
		dto.setDestination(bean.getDestination());
		dto.setPrice(bean.getPrice());
		
		int rs=dao.insertData(dto);
		if (rs==0) {
			model.addAttribute("error","Insert Fail");
			return"addSchedule";
		}
		return "redirect:/displaySchedule";
	}
	
	@RequestMapping(value = "/setupSearchDate", method = RequestMethod.GET)
	public String setupSearchDate(ModelMap model) {
		ArrayList<ScheduleResponseDTO> list=dao.selectAll();
		
		model.addAttribute("list",list);
		
		return "displaySchedule";
	}
	@RequestMapping(value = "/searchDate", method = RequestMethod.GET)
	public String  searchDate(@RequestParam("sid") String sid,
			@RequestParam("sdate") String sdate,
			 ModelMap model) {
		ScheduleRequestDTO dto = new ScheduleRequestDTO();
		dto.setBusId(sid);
		dto.setDate(sdate);
		
		
		ArrayList<ScheduleResponseDTO> scheduleBeanList = new ArrayList<ScheduleResponseDTO>();
		if (dao.searchData(dto).isEmpty()) {
			return "redirect:/setupSearchDate";
		}else {
			
			ArrayList<ScheduleResponseDTO> list=dao.searchData(dto);
			for (ScheduleResponseDTO res:list) {
				ScheduleResponseDTO dto1=new ScheduleResponseDTO();
				dto1.setBusId(res.getBusId());
				dto1.setDate(res.getDate());
				dto1.setTime(res.getTime());
				dto1.setBusType(res.getBusType());
				dto1.setSource(res.getSource());
				dto1.setDestination(res.getDestination());
				dto1.setPrice(res.getPrice());
				dto1.setDateId(res.getDateId());
				scheduleBeanList.add(dto1);
				
			}
		}
		model.addAttribute("list", scheduleBeanList);
		
		return "displaySchedule";
	}
	
	@RequestMapping(value="/setupUpdateSchedule/{dateId}",method=RequestMethod.GET)
	public ModelAndView setupUpdateSchedule(@PathVariable String dateId) {
		ScheduleRequestDTO dto=new ScheduleRequestDTO();
		dto.setDateId(dateId);
		return new ModelAndView("updateSchedule","bean",dao.selectOne(dto));
		
	}
	@RequestMapping(value="/updateSchedule",method=RequestMethod.POST)
	public String updateSchedule(@ModelAttribute("bean")@Validated ScheduleBean bean,
			BindingResult bs, ModelMap model) {
		if(bs.hasErrors()) {
			model.addAttribute("error","Update Fail");
			return "updateSchedule";
		}
		ScheduleRequestDTO dto=new ScheduleRequestDTO();
		dto.setDateId(bean.getDateId());
		dto.setDate(bean.getDate());
		dto.setTime(bean.getTime());
		dto.setBusId(bean.getBusId());
		dto.setBusType(bean.getBusType());
		dto.setSource(bean.getSource());
		dto.setDestination(bean.getDestination());
		dto.setPrice(bean.getPrice());
		int rs=dao.updateData(dto);
		if (rs==0) {
			model.addAttribute("error","Update Fail");
			return"updateSchedule";
		}
		return "redirect:/displaySchedule";
	}
	@RequestMapping(value="/deleteSchedule/{dateId}",method=RequestMethod.GET)
	public String deleteSchedule(@PathVariable String dateId,ModelMap model) {
		ScheduleRequestDTO dto=new ScheduleRequestDTO();
		dto.setDateId(dateId);
		int res=dao.deleteData(dto);
		if(res==0) {
			model.addAttribute("error","Delete Fail");
		}
		return "redirect:/displaySchedule";
	}

}
