package model;

import javax.validation.constraints.NotEmpty;

public class TravellerInfo {
	@NotEmpty
	private String name;
	@NotEmpty
	private String gender;
	@NotEmpty
	private String phone;
	@NotEmpty
	private String email;
	@NotEmpty
	private String request;
	public String getTravellername() {
		return name;
	}
	public void setTravellername(String travellername) {
		this.name = travellername;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRequest() {
		return request;
	}
	public void setRequest(String request) {
		this.request = request;
	}
	
}
