package adminmanagement.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import adminmanagement.model.AdminBean;



@Controller
public class AdminController {
  @RequestMapping(value = "/ggg")
  public String init(Model model) {
    model.addAttribute("msg", "Please Enter Your Login Details");
    return "LGN001";
  }

  @RequestMapping(value = "/login",method = RequestMethod.POST)
  public String submit(Model model, @ModelAttribute("loginBean") AdminBean loginBean,HttpSession session) {
    if (loginBean != null && loginBean.getAdminId() != null & loginBean.getPassword() != null) {
      if (loginBean.getAdminId().equals("Admin001") && loginBean.getPassword().equals("001122")) {
        model.addAttribute("msg", loginBean.getAdminId());
        
		session.setAttribute("loginBean",loginBean);
        return "MNU001";
      } else {
        model.addAttribute("error", "Invalid Details");
        return "LGN001";
      }}
     else {
        model.addAttribute("error", "Please enter Details");
        return "LGN001";
      }
    }
  @RequestMapping(value = "/logout", method = RequestMethod.GET)
  public String logout(HttpSession session) {
	  session.invalidate();
	  return "LGN001";
  }

  }

