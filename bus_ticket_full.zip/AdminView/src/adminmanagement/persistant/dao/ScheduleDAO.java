package adminmanagement.persistant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Service;
import adminmanagement.persistant.dto.ScheduleRequestDTO;
import adminmanagement.persistant.dto.ScheduleResponseDTO;

@Service("scheduleDao")

public class ScheduleDAO {
	public static Connection con=null;
	static {
		con=MyConnection.getConnection();
	}
	public int insertData(ScheduleRequestDTO dto) {
		int result=0;
		String sql="insert into schedule(date_id,date,time,bus_id,bus_type,source,destination,price) values(?,?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, dto.getDateId());
			ps.setString(2, dto.getDate());
			ps.setString(3, dto.getTime());
			ps.setString(4, dto.getBusId());
			ps.setString(5, dto.getBusType());
			ps.setString(6, dto.getSource());
			ps.setString(7, dto.getDestination());
			ps.setString(8, dto.getPrice());
			
			result=ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Database error"+e.getMessage());
		}
		return result;
	}

	public int updateData(ScheduleRequestDTO dto) {
		int result=0;
		String sql="update schedule set date=?,time=?,bus_id=? bus_type=?,source=?,destination=?,price=? where date_id=?";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);

			
			
			ps.setString(1, dto.getDate());
			ps.setString(2, dto.getTime());
			
			ps.setString(3, dto.getBusId());
			ps.setString(4, dto.getBusType());
			ps.setString(5, dto.getSource());
			ps.setString(6, dto.getDestination());
			ps.setString(7, dto.getPrice());
			
			ps.setString(8, dto.getDateId());
			
			result=ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Database error");
		}
		return result;
	}

	public int deleteData(ScheduleRequestDTO dto) {
		int result=0;
		String sql="delete from schedule where date_id=?";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, dto.getDateId());
			result=ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Database error");
		}
		return result;
	}

	public ScheduleResponseDTO selectOne(ScheduleRequestDTO dto) {
		ScheduleResponseDTO res=new ScheduleResponseDTO();
		String sql="select * from schedule where date_id=? ";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, dto.getDateId());
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				res.setDateId(rs.getString("date_id"));
				res.setDate(rs.getString("date"));
				res.setTime(rs.getString("time"));
				res.setBusId(rs.getString("bus_id"));
				res.setBusType(rs.getString("bus_type"));
				res.setSource(rs.getString("source"));
				res.setDestination(rs.getString("destination"));
				res.setPrice(rs.getString("price"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

	public ArrayList<ScheduleResponseDTO> selectAll(){
		ArrayList<ScheduleResponseDTO> list=new ArrayList<ScheduleResponseDTO>();
		String sql="select * from schedule  ORDER BY date ASC ";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				ScheduleResponseDTO res=new ScheduleResponseDTO();	
				res.setDateId(rs.getString("date_id"));
				res.setDate(rs.getString("date"));
				res.setTime(rs.getString("time"));
				res.setBusId(rs.getString("bus_id"));
				res.setBusType(rs.getString("bus_type"));
				res.setSource(rs.getString("source"));
				res.setDestination(rs.getString("destination"));
				res.setPrice(rs.getString("price"));
				list.add(res);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<ScheduleResponseDTO> searchData(ScheduleRequestDTO dto) {
		ArrayList<ScheduleResponseDTO> list=new ArrayList<>();
		String sql="SELECT * FROM schedule WHERE bus_id=? OR date=?";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,dto.getBusId());
			ps.setString(2,dto.getDate());
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				ScheduleResponseDTO res=new ScheduleResponseDTO();
				res.setDateId(rs.getString("date_id"));
				res.setDate(rs.getString("date"));
				
				res.setTime(rs.getString("time"));
				res.setBusId(rs.getString("bus_id"));
				res.setBusType(rs.getString("bus_type"));
				res.setSource(rs.getString("source"));
				res.setDestination(rs.getString("destination"));
				res.setPrice(rs.getString("price"));
				
				list.add(res);
			}
		} catch (SQLException e) {
			System.out.println("database error");
		}
		return list;
	}
	
	public ArrayList<ScheduleResponseDTO> searchTrip(ScheduleRequestDTO dto) {
		ArrayList<ScheduleResponseDTO> list=new ArrayList<>();
		String sql="SELECT * FROM schedule WHERE source=? AND destination=? AND date=?";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,dto.getSource());
			ps.setString(2,dto.getDestination());
			ps.setString(3,dto.getDate());
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				ScheduleResponseDTO res=new ScheduleResponseDTO();
				
				res.setDate(rs.getString("date"));
				res.setTime(rs.getString("time"));
				res.setBusId(rs.getString("bus_id"));
				res.setBusType(rs.getString("bus_type"));
				res.setSource(rs.getString("source"));
				res.setDestination(rs.getString("destination"));
				res.setPrice(rs.getString("price"));
				
				list.add(res);
			}
		} catch (SQLException e) {
			System.out.println("database error");
		}
		return list;
	}


}
