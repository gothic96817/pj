package adminmanagement.persistant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

import adminmanagement.model.AdminBean;
import adminmanagement.persistant.dto.AdminRequestDTO;
import adminmanagement.persistant.dto.AdminResponseDTO;
import adminmanagement.persistant.dto.BusRequestDTO;

@Service("adminDao")
public class AdminDAO {public static Connection con=null;
static {
	con=MyConnection.getConnection();
}

	public ArrayList<AdminResponseDTO> selectUser(AdminRequestDTO dto) {
		ArrayList<AdminResponseDTO> list=new ArrayList<>();
		String sql="SELECT * FROM admininfo WHERE admin_id=? AND password=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery(sql);
			while (rs.next()) {
				AdminResponseDTO adm=new AdminResponseDTO();
				adm.setAdminId(rs.getString("adminId"));
				adm.setPassword(rs.getString("password"));
				list.add(adm);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	

}
