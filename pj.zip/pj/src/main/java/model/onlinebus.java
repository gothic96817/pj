package model;

public class onlinebus {
	 private String busname;
	 private String fromtrip;
	 private String totrip;
	 private String departuretime;
	 private String arrivaltime;
	public String getBusname() {
		return busname;
	}
	public void setBusname(String busname) {
		this.busname = busname;
	}
	public String getFromtrip() {
		return fromtrip;
	}
	public void setFromtrip(String fromtrip) {
		this.fromtrip = fromtrip;
	}
	public String getTotrip() {
		return totrip;
	}
	public void setTotrip(String totrip) {
		this.totrip = totrip;
	}
	public String getDeparturetime() {
		return departuretime;
	}
	public void setDeparturetime(String departuretime) {
		this.departuretime = departuretime;
	}
	public String getArrivaltime() {
		return arrivaltime;
	}
	public void setArrivaltime(String arrivaltime) {
		this.arrivaltime = arrivaltime;
	}
	 
}
