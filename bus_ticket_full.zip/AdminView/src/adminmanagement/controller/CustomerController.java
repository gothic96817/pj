package adminmanagement.controller;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import adminmanagement.model.BusBean;
import adminmanagement.model.CustomerBean;
import adminmanagement.model.SeatBean;
import adminmanagement.persistant.dao.CustomerDAO;
import adminmanagement.persistant.dao.ScheduleDAO;
import adminmanagement.persistant.dto.BusRequestDTO;
import adminmanagement.persistant.dto.CustomerRequestDTO;
import adminmanagement.persistant.dto.ScheduleRequestDTO;
import adminmanagement.persistant.dto.ScheduleResponseDTO;
import adminmanagement.persistant.dto.SeatRequestDTO;


@Controller
public class CustomerController {
	
		@Autowired
		private CustomerDAO cusdao;
		@Autowired
		private ScheduleDAO scheduledao;
		@Autowired
		private ScheduleDAO seatdao;
		
		@RequestMapping(value="/",method=RequestMethod.GET)
		public String displayView(ModelMap model) {

			
			return "index";
		}
		
		@RequestMapping(value="/setupaddCustomer",method=RequestMethod.GET)
		public ModelAndView setupaddCustomer() {
			return new ModelAndView("travellerInfo","bean",new CustomerBean());
			
		}
		
		
		@RequestMapping(value = "/searchTrip", method = RequestMethod.GET)
		public String  searchDate(@RequestParam("source") String source,@RequestParam("destination") String destination,
				@RequestParam("date") String date,
				 ModelMap model) {
			ScheduleRequestDTO dto = new ScheduleRequestDTO();
			dto.setSource(source);
			dto.setDestination(destination);
			dto.setDate(date);
			
			
			ArrayList<ScheduleResponseDTO> scheduleBeanList = new ArrayList<ScheduleResponseDTO>();
			if (scheduledao.searchTrip(dto).isEmpty()) {
				return "searchTrip";
			}else {
				
				ArrayList<ScheduleResponseDTO> list=scheduledao.searchTrip(dto);
				for (ScheduleResponseDTO res:list) {
					ScheduleResponseDTO dto1=new ScheduleResponseDTO();
					dto1.setBusId(res.getBusId());
					dto1.setDate(res.getDate());
					dto1.setTime(res.getTime());
					dto1.setBusType(res.getBusType());
					dto1.setSource(res.getSource());
					dto1.setDestination(res.getDestination());
					dto1.setPrice(res.getPrice());
					dto1.setDateId(res.getDateId());
					scheduleBeanList.add(dto1);
					
				}
			}
			model.addAttribute("list", scheduleBeanList);
			
			return "searchTrip";
		}
		
		
		@RequestMapping(value="/addCustomer",method=RequestMethod.POST)
		public String addBus(@ModelAttribute("bean")@Validated CustomerBean bean,
				BindingResult bs, ModelMap model) {
			if(bs.hasErrors()) {
				return "travellerInfo";
			}
			CustomerRequestDTO dto=new CustomerRequestDTO();
			dto.setName(bean.getName());
			dto.setGender(bean.getGender());
			dto.setPhone(bean.getPhone());
			dto.setEmail(bean.getEmail());
			dto.setRequest(bean.getRequest());
			
			
			int rs=cusdao.insert(dto);
			if (rs==0) {
				model.addAttribute("error","Insert Fail");
				return"travellerInfo";
			}
			return "addBus";
		}
		
		@RequestMapping(value="/addCusto",method=RequestMethod.POST)
		public String add(@ModelAttribute("bean")@Validated CustomerBean bean,
				BindingResult bs, ModelMap model) {
			if(bs.hasErrors()) {
				return "travellerInfo";
			}
			CustomerRequestDTO dto=new CustomerRequestDTO();
			dto.setName(bean.getName());
			dto.setGender(bean.getGender());
			dto.setPhone(bean.getPhone());
			dto.setEmail(bean.getEmail());
			dto.setRequest(bean.getRequest());
			dto.setSeatNo(bean.getSeatNo());
			dto.setSource(bean.getSource());
			dto.setDestination(bean.getDestination());
			dto.setTotalPrice(bean.getTotalPrice());
			dto.setBusId(bean.getBusId());
			dto.setBusType(bean.getBusType());
			
			int rs=cusdao.insertData(dto);
			if (rs==0) {
				model.addAttribute("error","Insert Fail");
				return"travellerInfo";
			}
			return "addBus";
		}
		
		
		
		@RequestMapping(value="/selectSeat/{busId}",method=RequestMethod.GET)
		public ModelAndView setupUpdateBus(SeatBean bean,@PathVariable String busId) {
			SeatRequestDTO dto=new SeatRequestDTO();
			dto.setBusId(busId);
			return new ModelAndView("selectSeat","bean",bean);
			
		}
		
	}

