package model;

import javax.validation.constraints.NotEmpty;

public class SeatNumber {
	@NotEmpty
	private String seatNumber;
	
	@NotEmpty
	private String totalseat;
	
	public String getTotalseat() {
		return totalseat;
	}

	public void setTotalseat(String totalseat) {
		this.totalseat = totalseat;
	}

	public String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}

	
}
