package dto;


public class UserRequestDTO {	
	private String searchtripid;
	private String starttime;
	private String fromtrip;
	private String totrip;
	private String departuretime;
	private String arrivaltime;
	private String busname;
	private String mmk;
	private String totalseat;
	public String getSearchtripid() {
		return searchtripid;
	}
	public void setSearchtripid(String searchtripid) {
		this.searchtripid = searchtripid;
	}
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public String getFromtrip() {
		return fromtrip;
	}
	public void setFromtrip(String fromtrip) {
		this.fromtrip = fromtrip;
	}
	public String getTotrip() {
		return totrip;
	}
	public void setTotrip(String totrip) {
		this.totrip = totrip;
	}
	public String getDeparturetime() {
		return departuretime;
	}
	public void setDeparturetime(String departuretime) {
		this.departuretime = departuretime;
	}
	public String getArrivaltime() {
		return arrivaltime;
	}
	public void setArrivaltime(String arrivaltime) {
		this.arrivaltime = arrivaltime;
	}
	public String getBusname() {
		return busname;
	}
	public void setBusname(String busname) {
		this.busname = busname;
	}
	public String getMmk() {
		return mmk;
	}
	public void setMmk(String mmk) {
		this.mmk = mmk;
	}
	public String getTotalseat() {
		return totalseat;
	}
	public void setTotalseat(String totalseat) {
		this.totalseat = totalseat;
	}
	
}
