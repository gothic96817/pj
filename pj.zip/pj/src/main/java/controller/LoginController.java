

package controller;

import java.util.ArrayList;

import java.util.List;

import org.apache.tomcat.jni.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import dao.UserDAO;
import dto.UserRequestDTO;
import dto.UserResponseDTO;
import model.SeatNumber;
import model.TravellerInfo;
import model.UserBean;

@Controller
public class LoginController {
	
	@Autowired
	UserDAO userDao;
	
	@RequestMapping(value = "/select", method = RequestMethod.GET)
	   public String redirect(@ModelAttribute("ob")SeatNumber ob, 
			      BindingResult result,ModelMap model) {	
		model.addAttribute("seatnumber", ob.getSeatNumber());
		model.addAttribute("totalseat", ob.getTotalseat());
		
		return "seatSelect";
	   }
	
	@RequestMapping(value="/selectseat" , method=RequestMethod.POST)
	public String login(@ModelAttribute("seatNumbe") SeatNumber seat,ModelMap model) {
//			model.addAttribute("seatnumber", seat.getSeatNumber());
//			model.addAttribute("totalseat", seat.getTotalseat());
			return "travellerInfo";
	}
	
	@RequestMapping(value="/pay" , method=RequestMethod.POST)
	public String pay(@ModelAttribute("payments") TravellerInfo info,ModelMap model) {
			model.addAttribute("name", info.getTravellername());
			model.addAttribute("gender", info.getGender());
			model.addAttribute("phone", info.getPhone());
			model.addAttribute("email", info.getEmail());
			model.addAttribute("request", info.getRequest());
			return "payment";	
	}
	
	
	@RequestMapping(value="/", method=RequestMethod.GET)
	public ModelAndView show()
	{
		ModelAndView modelAndView = new ModelAndView("index", "bean", new User()); 
		return modelAndView;
		
	}
	
	@RequestMapping(value="/searchTrip" , method=RequestMethod.GET)
	public String searchUser(@RequestParam("fromtrip") String fromtrip, @RequestParam("totrip") String totrip, ModelMap model) {
		UserRequestDTO dto = new UserRequestDTO();
		dto.setFromtrip(fromtrip);
		dto.setTotrip(totrip);
		List<UserResponseDTO> list = new ArrayList<UserResponseDTO>();
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		if (fromtrip.isBlank() && totrip.isBlank()){
			list = userDao.selectAll();
		}else {
			list=userDao.searchData(dto);
			
		}
		if (list.size() == 0) {
			
			model.addAttribute("msg", "User not found!!");
			return "index";
		} else {
			for (UserResponseDTO res:list) {
			
				UserBean userBean = new UserBean();
				userBean.setSearchtripid(res.getSearchtripid());
				userBean.setStarttime(res.getStarttime());
				userBean.setFromtrip(res.getFromtrip());
				userBean.setTotrip(res.getTotrip());
				userBean.setDeparturetime(res.getDeparturetime());
				userBean.setArrivaltime(res.getArrivaltime());
				userBean.setStarttime(res.getStarttime());
				userBean.setBusname(res.getBusname());
				userBean.setMmk(res.getMmk());
				userBean.setTotalseat(res.getTotalseat());
				userBeanList.add(userBean);
			}
		}
		model.addAttribute("list", userBeanList);
		return "NewFile";
	}
	
}

