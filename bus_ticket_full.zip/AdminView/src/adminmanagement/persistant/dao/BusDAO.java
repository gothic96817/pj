package adminmanagement.persistant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

import adminmanagement.persistant.dto.BusRequestDTO;
import adminmanagement.persistant.dto.BusResponseDTO;

@Service("busDao")
public class BusDAO {public static Connection con=null;
static {
	con=MyConnection.getConnection();
}
public int insertData(BusRequestDTO dto) {
	int result=0;
	String sql="insert into bus(bus_id,bus_type,source,destination,total_seat,price) values(?,?,?,?,?,?)";
	
	try {
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, dto.getBusId());
		ps.setString(2, dto.getBusType());
		ps.setString(3, dto.getSource());
		ps.setString(4, dto.getDestination());
		ps.setString(5, dto.getTotalSeat());
		ps.setString(6, dto.getPrice());
		result=ps.executeUpdate();
	} catch (SQLException e) {
		System.out.println("Database error"+e.getMessage());
	}
	return result;
}

public int updateData(BusRequestDTO dto) {
	int result=0;
	String sql="update bus set bus_type=?,source=?,destination=?,total_seat=?,price=? where bus_id=?";
	
	try {
		PreparedStatement ps=con.prepareStatement(sql);

		
		
		
		ps.setString(1, dto.getBusType());
		ps.setString(2, dto.getSource());
		ps.setString(3, dto.getDestination());
		ps.setString(4, dto.getTotalSeat());
		ps.setString(5, dto.getPrice());
		ps.setString(6, dto.getBusId());
		result=ps.executeUpdate();
	} catch (SQLException e) {
		System.out.println("Database error");
	}
	return result;
}

public int deleteData(BusRequestDTO dto) {
	int result=0;
	String sql="delete from bus where bus_id=?";
	
	try {
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, dto.getBusId());
		result=ps.executeUpdate();
	} catch (SQLException e) {
		System.out.println("Database error");
	}
	return result;
}


public BusResponseDTO selectOne(BusRequestDTO dto) {
	BusResponseDTO res=new BusResponseDTO();
	String sql="select * from bus where bus_id=? ";
	try {
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, dto.getBusId());
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			res.setBusId(rs.getString("bus_id"));
			res.setBusType(rs.getString("bus_type"));
			res.setSource(rs.getString("source"));
			res.setDestination(rs.getString("destination"));
			res.setTotalSeat(rs.getString("total_seat"));
			res.setPrice(rs.getString("price"));
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return res;
}


public ArrayList<BusResponseDTO> search(BusRequestDTO dto){
	ArrayList<BusResponseDTO> search=new ArrayList<BusResponseDTO>();
	String sql="select * from bus where bus_id=? OR bus_type=? OR source=? OR destination=?";
	try {
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			BusResponseDTO res=new BusResponseDTO();	
			res.setBusId(rs.getString("bus_id"));
			res.setBusType(rs.getString("bus_type"));
			res.setSource(rs.getString("source"));
			res.setDestination(rs.getString("destination"));
			res.setTotalSeat(rs.getString("total_seat"));
			res.setPrice(rs.getString("price"));
			search.add(res);
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return search;
}

public ArrayList<BusResponseDTO> searchData(BusRequestDTO dto) {
	ArrayList<BusResponseDTO> list=new ArrayList<>();
	String sql="SELECT * FROM bus WHERE bus_id=? OR bus_type=? OR source=? OR destination=? ";
	try {
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,dto.getBusId());
		ps.setString(2,dto.getBusType());
		ps.setString(3,dto.getSource());
		ps.setString(4,dto.getDestination());
		
		//ps.setInt(3,dto.getStudentAttend());
		ResultSet rs=ps.executeQuery();
		while (rs.next()) {
			BusResponseDTO res=new BusResponseDTO();
			res.setBusId(rs.getString("bus_id"));
			res.setBusType(rs.getString("bus_type"));
			res.setSource(rs.getString("source"));
			res.setDestination(rs.getString("destination"));
			res.setTotalSeat(rs.getString("total_seat"));
			res.setPrice(rs.getString("price"));
			//res.setCourse(rs.getString("course"));
			list.add(res);
		}
	} catch (SQLException e) {
		System.out.println("database error");
	}
	return list;
}


public ArrayList<BusResponseDTO> selectAll(){
	ArrayList<BusResponseDTO> list=new ArrayList<BusResponseDTO>();
	String sql="select * from bus";
	try {
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			BusResponseDTO res=new BusResponseDTO();	
			res.setBusId(rs.getString("bus_id"));
			res.setBusType(rs.getString("bus_type"));
			res.setSource(rs.getString("source"));
			res.setDestination(rs.getString("destination"));
			res.setTotalSeat(rs.getString("total_seat"));
			res.setPrice(rs.getString("price"));
			list.add(res);
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return list;
}


}
