/*<spinner-component name="numberOfSeats"
      value="2" min="1" max="4" unit="Person" unit-plural="Persons">
  </spinner-component>*
*/

class MyComponent extends HTMLElement {
    static get observedAttributes() {
        return ['value'];
    }

    constructor() {
        super();

        this.innerHTML = `
        <div class="d-flex flex-row border rounded bg-white">
            <button class="btn btn-outline-secondary border-0 px-4" id="decrement-counter" name="decrement-counter">
                <i class="fa fa-minus" id="decrement-icon" style="color:grey"></i>
            </button>
            <div class="flex-grow-1 text-center border-right border-left">
                <span id="countDisplay"></span>
            </div>
            <button class="btn btn-outline-secondary border-0 px-4" id="increment-counter" name="increment-counter">
                <i class="fa fa-plus" id="increment-icon" style="color:grey"></i>
            </button>
        </div>
        <input type="hidden" name="${this.getAttribute("name")}" id="countInput"/>`; 

        this.countDisplayElement = document.getElementById('countDisplay');    
        this.countInputElement = document.getElementById('countInput');
    }


    connectedCallback() {      
        let minValue = this.getAttribute('min') || 1;
        let maxValue = this.getAttribute('max') || 10;        
        let count = this.getAttribute('value');
        //console.log("connectedCallback: value", count);
        if(count <= minValue){
            document.getElementById('decrement-counter').disabled = true;
            document.getElementById('decrement-icon').style.color = '#bfbfbf';
        }
        if(count >= maxValue){
            document.getElementById('increment-counter').disabled = true;
            document.getElementById('increment-icon').style.color = '#bfbfbf';
        }

        let rootCompo = this;

        document.getElementById('increment-counter').addEventListener("click", (event) => {
            event.preventDefault();
            document.getElementById('decrement-counter').disabled = false;
            document.getElementById('decrement-icon').style.color = 'grey';

            if(count == maxValue-1){
                count++;
                rootCompo.setAttribute('value', count);
                document.getElementById('increment-counter').disabled = true;
                document.getElementById('increment-icon').style.color = '#bfbfbf';

            }else if(count < maxValue) {
                count++;
                //console.log("increment call", count);
                rootCompo.setAttribute('value', count);
            }

        }); 

        document.getElementById('decrement-counter').addEventListener("click", (event) => {
            event.preventDefault();
            document.getElementById('increment-counter').disabled = false;
            document.getElementById('increment-icon').style.color = 'grey';
            if(count == parseInt(minValue)+1){
                count--;
                rootCompo.setAttribute('value', count);
                document.getElementById('decrement-counter').disabled = true;
                document.getElementById('decrement-icon').style.color = '#bfbfbf';

            }else if(count > minValue) {
                count--;
                //console.log("decrement call", count);
                rootCompo.setAttribute('value', count);
            }
        });

        //this.setAttribute('value', 1);
    }

    attributeChangedCallback(name, oldValue, newValue) {
        //console.log("attributeChangedCallback", name, oldValue, newValue);

        let singularUnit = this.getAttribute('unit') || "";
        let pluralUnit = this.getAttribute('unit-plural') || singularUnit;

        let unitDescriptionHtml = `<span class='text-muted'>${newValue <= 1 ? singularUnit: pluralUnit}</span>`;
        this.countDisplayElement.innerHTML = newValue + ' ' + unitDescriptionHtml;        
        this.countInputElement.value = newValue;
    }
}
customElements.define('spinner-component', MyComponent);