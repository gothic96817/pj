package adminmanagement.persistant.dao;

import org.springframework.stereotype.Service;


import adminmanagement.persistant.dto.CustomerRequestDTO;
import adminmanagement.persistant.dto.CustomerResponseDTO;
import adminmanagement.persistant.dto.ScheduleRequestDTO;
import adminmanagement.persistant.dto.ScheduleResponseDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
	


	@Service("customerDao")
	public class CustomerDAO {public static Connection con=null;
	static {
		con=MyConnection.getConnection();
	}
	public int insertData(CustomerRequestDTO dto) {
		int result=0;
		String sql="insert into customer(name,gender,phone,email,request,seat_no,source,destination,total_price,busId,busType) values(?,?,?,?,?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getGender());
			ps.setString(3, dto.getPhone());
			ps.setString(4, dto.getEmail());
			ps.setString(5, dto.getRequest());
			ps.setString(6, dto.getSeatNo());
			ps.setString(7, dto.getSource());
			ps.setString(8, dto.getDestination());
			ps.setString(9, dto.getTotalPrice());
			ps.setString(10, dto.getBusId());
			ps.setString(11, dto.getBusType());
			
			
			result=ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Database error"+e.getMessage());
		}
		return result;
	}

	
	public int insert(CustomerRequestDTO dto) {
		int result=0;
		String sql="insert into customer(name,gender,phone,email,request) values(?,?,?,?,?)";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getGender());
			ps.setString(3, dto.getPhone());
			ps.setString(4, dto.getEmail());
			ps.setString(5, dto.getRequest());
			
			
			
			result=ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Database error"+e.getMessage());
		}
		return result;
	}


	public ArrayList<CustomerResponseDTO> selectAll(){
		ArrayList<CustomerResponseDTO> list=new ArrayList<CustomerResponseDTO>();
		String sql="select * from customer";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				CustomerResponseDTO res=new CustomerResponseDTO();	
				res.setName(rs.getString("name"));
				res.setGender(rs.getString("gender"));
				res.setEmail(rs.getString("email"));
				res.setRequest(rs.getString("request"));
				res.setSeatNo(rs.getString("seat_no"));
				res.setSource(rs.getString("source"));
				res.setDestination(rs.getString("destination"));
				res.setTotalPrice(rs.getString("total_price"));
				res.setBusId(rs.getString("bus_id"));
				res.setBusType(rs.getString("bus_type"));
				res.setSource(rs.getString("source"));
				
				list.add(res);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}


	public ArrayList<ScheduleResponseDTO> searchData(ScheduleRequestDTO dto) {
		ArrayList<ScheduleResponseDTO> list=new ArrayList<>();
		String sql="SELECT * FROM bus WHERE source=? OR destination=? OR date=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setString(1,dto.getSource());
			ps.setString(2,dto.getDestination());
			ps.setString(3,dto.getDate());
			
			
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				ScheduleResponseDTO res=new ScheduleResponseDTO();
				res.setDate(rs.getString("date"));
				res.setTime(rs.getString("time"));
				res.setBusId(rs.getString("bus_id"));
				res.setBusType(rs.getString("bus_type"));
				res.setSource(rs.getString("source"));
				res.setDestination(rs.getString("destination"));
				res.setPrice(rs.getString("price"));
				
				list.add(res);
			}
		} catch (SQLException e) {
			System.out.println("database error");
		}
		return list;
	}


}
