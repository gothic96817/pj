package adminmanagement.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import adminmanagement.model.BusBean;
import adminmanagement.persistant.dao.BusDAO;
import adminmanagement.persistant.dto.BusRequestDTO;
import adminmanagement.persistant.dto.BusResponseDTO;



@Controller
public class BusController {
	@Autowired
	private BusDAO dao;
	
	@RequestMapping(value="/displayBus",method=RequestMethod.GET)
	public String displayView(ModelMap model) {
		ArrayList<BusResponseDTO> list=dao.selectAll();
		model.addAttribute("list",list);
		return "displayBus";
	}
	
	@RequestMapping(value = "/searchBus", method = RequestMethod.GET)
	public String  searchBus(@RequestParam("sid") String sid,
			@RequestParam("stype") String stype,
			@RequestParam("ssource") String ssource,
			@RequestParam("sdestination") String sdestination,
			 ModelMap model) {
		BusRequestDTO dto = new BusRequestDTO();
		dto.setBusId(sid);
		dto.setBusType(stype);
		dto.setSource(ssource);
		dto.setDestination(sdestination);
		
		ArrayList<BusBean> busBeanList = new ArrayList<BusBean>();
		if (dao.searchData(dto).isEmpty()) {
			return "redirect:/displayBus";
		}else {
			
			ArrayList<BusResponseDTO> list=dao.searchData(dto);
			for (BusResponseDTO res:list) {
				BusBean busBean = new BusBean();
				busBean.setBusId(res.getBusId());
				busBean.setBusType(res.getBusType());
				busBean.setSource(res.getSource());
				busBean.setDestination(res.getDestination());
				busBean.setPrice(res.getPrice());
				busBeanList.add(busBean);
			}
		}
		model.addAttribute("list", busBeanList);
		return "displayBus";
	}
	
	@RequestMapping(value="/setupaddBus",method=RequestMethod.GET)
	public ModelAndView setupaddBus(BusBean bean,ModelMap model) {
		ArrayList<BusResponseDTO> list=dao.selectAll();
		if (list.size()==0) {
			
			bean.setBusId("BUS001");
		}else {
			int tempId = Integer.parseInt (list.get (list.size()-1).getBusId().substring(3))+1;
					String busId=String.format("BUS%03d",tempId); 
					bean.setBusId(busId) ;
		}return new ModelAndView("addBus","bean",bean);
	}
	
	@RequestMapping(value="/addBus",method=RequestMethod.POST)
	public String addBus(@ModelAttribute("bean")@Validated BusBean bean,
			BindingResult bs, ModelMap model) {
		if(bs.hasErrors()) {
			return "addBus";
		}
		BusRequestDTO dto=new BusRequestDTO();
		dto.setBusId(bean.getBusId());
		dto.setBusType(bean.getBusType());
		dto.setSource(bean.getSource());
		dto.setDestination(bean.getDestination());
		dto.setPrice(bean.getPrice());
		int rs=dao.insertData(dto);
		if (rs==0) {
			model.addAttribute("error","Insert Fail");
			return"addBus";
		}
		return "redirect:/displayBus";
	}
	@RequestMapping(value="/setupUpdateBus/{busId}",method=RequestMethod.GET)
	public ModelAndView setupUpdateBus(@PathVariable String busId) {
		BusRequestDTO dto=new BusRequestDTO();
		dto.setBusId(busId);
		return new ModelAndView("updateBus","bean",dao.selectOne(dto));
		
	}
	@RequestMapping(value="/updateBus",method=RequestMethod.POST)
	public String updateBus(@ModelAttribute("bean")@Validated BusBean bean,
			BindingResult bs, ModelMap model) {
		if(bs.hasErrors()) {
			model.addAttribute("error","Update Fail");
			return "updateBus";
		}
		BusRequestDTO dto=new BusRequestDTO();
		dto.setBusId(bean.getBusId());
		dto.setBusType(bean.getBusType());
		dto.setSource(bean.getSource());
		dto.setDestination(bean.getDestination());
		dto.setPrice(bean.getPrice());
		int rs=dao.updateData(dto);
		if (rs==0) {
			model.addAttribute("error","Update Fail");
			return"updateBus";
		}
		return "redirect:/displayBus";
	}
	
	@RequestMapping(value = "/updateBuss", method = RequestMethod.POST)
	public String updateStudent(@ModelAttribute("bean") @Validated BusBean bean, BindingResult bs,
			ModelMap model) {
		if (bs.hasErrors()) {
			model.addAttribute("error","Update Fail");
			return "updateBus";
		}
		BusRequestDTO dto = new BusRequestDTO();
		dto.setBusId(bean.getBusId());
		dto.setBusType(bean.getBusType());
		dto.setSource(bean.getSource());
		dto.setDestination(bean.getDestination());
		dto.setPrice(bean.getPrice());
		int i = dao.updateData(dto);
		if (i == 0) {
			model.addAttribute("msg", "Update Fail!!");
			return "redirect:/updateBus";
		}	model.addAttribute("msg", " Update Successful!!!");
			return "redirect:/displayBus";
			
		
	}
	
	@RequestMapping(value="/deleteBus/{busId}",method=RequestMethod.GET)
	public String deleteBus(@PathVariable String busId,ModelMap model) {
		BusRequestDTO dto=new BusRequestDTO();
		dto.setBusId(busId);
		int res=dao.deleteData(dto);
		if(res==0) {
			model.addAttribute("error","Delete Fail");
		}
		return "redirect:/displayBus";
	}
	
	@RequestMapping(value="/displayTicket",method=RequestMethod.GET)
	public String displayTicket(ModelMap model) {
		
		return "displayTicket";
	}
	@RequestMapping(value="/seatDisplay/{busId}",method=RequestMethod.GET)
	public String seatDisplay(ModelMap model) {
		
		return "seatDisplay";
	}

}
