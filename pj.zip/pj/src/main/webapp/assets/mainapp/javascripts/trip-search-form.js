$(document).ready(function(){
    $('#selectFrom').selectpicker();
    $('#selectTo').selectpicker();

    $('#departureDate').pickadate({
        format: 'yyyy-mm-dd',
        min: new Date()
    });

    $('#bookingSearchDepartureDate').pickadate({
        format: 'yyyy-mm-dd',
    });

    const tripSearchForm = document.getElementById('tripSearchForm');
    tripSearchForm.addEventListener('submit', function(event) {
        let departureDate = $('#departureDate').val();
        //alert("Departure Date: " + departureDate);
        if(!departureDate) {
            //alert("Date is missing!");
            event.preventDefault();
            tripSearchForm.reportValidity();

            $('#departureDate').addClass('is-invalid');

            /*$('#departureDate').popover({
                content : "Date is required.",
                placement: "bottom",
                focus: true
            });
            $('#departureDate').popover('show') */
        }
    });


});